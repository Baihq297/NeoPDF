"""Small page-management and security dialogs."""
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QMessageBox, QInputDialog
)

def merge_dialog(parent, backend):
    paths, _ = QFileDialog.getOpenFileNames(parent, "Select PDFs to merge", "", "PDF files (*.pdf)")
    if not paths: return
    out, _ = QFileDialog.getSaveFileName(parent, "Save merged PDF", "merged.pdf", "PDF files (*.pdf)")
    if not out: return
    try:
        backend.merge(paths, out)
        QMessageBox.information(parent, "NeoPDF", "Merged PDF saved:\n" + out)
    except Exception as e: QMessageBox.critical(parent, "Merge failed", str(e))

def split_dialog(parent, backend):
    ranges, ok = QInputDialog.getText(parent, "Split PDF", "Page ranges separated by comma (e.g. 1-5,6-10):")
    if not ok or not ranges: return
    folder = QFileDialog.getExistingDirectory(parent, "Choose output folder")
    if not folder: return
    try:
        outputs = backend.split([x.strip() for x in ranges.split(",")], folder)
        QMessageBox.information(parent, "NeoPDF", "Created:\n" + "\n".join(outputs))
    except Exception as e: QMessageBox.critical(parent, "Split failed", str(e))

def protect_dialog(parent, backend):
    user, ok = QInputDialog.getText(parent, "PDF password", "User password:")
    if not ok: return
    owner, ok = QInputDialog.getText(parent, "PDF password", "Owner password:")
    if not ok: return
    out, _ = QFileDialog.getSaveFileName(parent, "Save protected PDF", "protected.pdf", "PDF files (*.pdf)")
    if not out: return
    try:
        backend.protect(out, user, owner)
        QMessageBox.information(parent, "NeoPDF", "Protected PDF saved:\n" + out)
    except Exception as e: QMessageBox.critical(parent, "Protection failed", str(e))
