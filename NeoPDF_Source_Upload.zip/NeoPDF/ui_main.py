"""Main NeoPDF window and document tabs."""
import os
import fitz
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QFrame, QPushButton,
    QTabWidget, QFileDialog, QMessageBox, QInputDialog, QToolBar, QAction,
    QLabel, QSpinBox, QStatusBar
)
from pdf_backend import PDFBackend
from ui_viewer import PDFViewer
from ui_print_dialog import PrintDialog
from ui_editor import merge_dialog, split_dialog, protect_dialog
from ui_settings import SettingsDialog
from document_history import add_recent, create_recovery_snapshot, load_recent
from ui_reorder import ReorderDialog
from ui_object_editor import ObjectEditorDialog

class DocumentTab(QWidget):
    def __init__(self, path):
        super().__init__()
        self.backend = PDFBackend(path)
        self.viewer = PDFViewer(self.backend)
        self.page = 0
        self.viewer.page_changed_callback = self._page_changed
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.viewer)
        self.viewer.show_page(0)

    def _page_changed(self, index):
        self.page = index

    def close_document(self):
        self.backend.close()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NeoPDF 5.0 — READ • EDIT • PRINT")
        self.resize(1440, 900)
        self.setMinimumSize(1080, 680)
        self.setStyleSheet("""
            QMainWindow, QWidget { background: #f4f7f9; color: #17252d; font-family: Segoe UI; font-size: 10pt; }
            QTabWidget::pane { border: 1px solid #dce5e9; background: #ffffff; border-radius: 8px; }
            QTabBar::tab { background: #e7eef1; padding: 11px 18px; margin-right: 3px; border-top-left-radius: 7px; border-top-right-radius: 7px; }
            QTabBar::tab:selected { background: #ffffff; color: #087e83; font-weight: 600; }
            QToolBar { background: #ffffff; border: 0; border-bottom: 1px solid #dce5e9; spacing: 6px; padding: 7px; }
            QToolButton { padding: 7px 10px; border-radius: 6px; }
            QToolButton:hover { background: #e5f4f3; }
            QPushButton { background: #e7eef1; border: 1px solid #d5e0e4; border-radius: 7px; padding: 9px 12px; }
            QPushButton:hover { background: #d9eeee; border-color: #83c4c2; }
            QPushButton:disabled { color: #9aa8ad; }
            QLineEdit, QComboBox, QSpinBox { background: #ffffff; border: 1px solid #ccd9de; border-radius: 6px; padding: 7px; }
            QStatusBar { background: #ffffff; border-top: 1px solid #dce5e9; }
        """)
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.setCentralWidget(self._layout())
        self.setStatusBar(QStatusBar())
        self._toolbar()
        self.autosave_timer = QTimer(self)
        self.autosave_timer.timeout.connect(self._autosave_documents)
        self.autosave_timer.start(60000)  # recovery snapshot every 60 seconds

    def _layout(self):
        central = QWidget()
        row = QHBoxLayout(central); row.setContentsMargins(0, 0, 0, 0); row.setSpacing(0)
        sidebar = QFrame(); sidebar.setFixedWidth(210)
        sidebar.setStyleSheet("QFrame{background:#152b35;} QLabel{background:transparent;} QPushButton{text-align:left;padding:12px 13px;border:0;border-radius:7px;color:#eaf4f5;background:transparent;} QPushButton:hover{background:#244852;}")
        side = QVBoxLayout(sidebar)
        brand = QLabel("  NeoPDF"); brand.setStyleSheet("font-size:25px;font-weight:750;color:#fff;padding:20px 4px;")
        side.addWidget(brand)
        def section(text):
            label = QLabel(text)
            label.setStyleSheet("color:#83c8c7;font-size:10px;font-weight:700;padding:15px 12px 4px;letter-spacing:1px;")
            side.addWidget(label)

        section("READ")
        for label, callback in [
            ("＋  Open document", self.open_pdf),
            ("⌕  Search in PDF", self.search_pdf),
            ("◀  Previous page", lambda: self.navigate(-1)),
            ("▶  Next page", lambda: self.navigate(1)),
        ]:
            b = QPushButton(label); b.clicked.connect(callback); side.addWidget(b)

        section("EDIT")
        for label, callback in [
            ("▤  Page management", self.page_management),
            ("↕  Reorder pages", self.reorder_pages),
            ("✎  Replace text", self.replace_text),
            ("▧  Edit page objects", self.edit_objects),
            ("▧  Insert image", self.insert_image),
            ("◆  Protect PDF", self.protect_pdf),
            ("🖍  Highlight", lambda: self.annotate("highlight")),
            ("＿  Underline", lambda: self.annotate("underline")),
        ]:
            b = QPushButton(label); b.clicked.connect(callback); side.addWidget(b)

        section("PRINT")
        b = QPushButton("▣  Print & calculate")
        b.clicked.connect(self.open_print); side.addWidget(b)
        side.addStretch()
        settings = QPushButton("⚙  Settings")
        settings.clicked.connect(self.show_settings)
        side.addWidget(settings)
        row.addWidget(sidebar); row.addWidget(self.tabs, 1)
        return central

    def _toolbar(self):
        bar = QToolBar("Document tools"); self.addToolBar(bar)
        actions = [
            ("Open", self.open_pdf), ("Search", self.search_pdf),
            ("Save As", self.save_as), ("Print / Calculate", self.open_print),
            ("Zoom −", lambda: self.zoom(0.85)), ("Zoom +", lambda: self.zoom(1.18)),
            ("Previous page", lambda: self.navigate(-1)), ("Next page", lambda: self.navigate(1)),
            ("Highlight", lambda: self.annotate("highlight")),
            ("Underline", lambda: self.annotate("underline")),
            ("Reorder pages", self.reorder_pages),
            ("Replace text", self.replace_text),
            ("Edit objects", self.edit_objects),
            ("Insert image", self.insert_image),
        ]
        for name, fn in actions:
            a = QAction(name, self); a.triggered.connect(fn); bar.addAction(a)
            if name == "Search":
                a.setShortcut("Ctrl+F")
            elif name == "Save As":
                a.setShortcut("Ctrl+Shift+S")

    def current_tab(self):
        return self.tabs.currentWidget()

    def open_pdf(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Open PDF documents", "", "PDF files (*.pdf)")
        for path in paths:
            try:
                recovery_path = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"),
                                             "NeoPDF", "recovery_" + os.path.basename(path).replace(" ", "_"))
                open_path = path
                if os.path.exists(recovery_path):
                    answer = QMessageBox.question(
                        self, "Pemulihan dokumen",
                        "Ditemukan snapshot pemulihan untuk dokumen ini. Buka snapshot pemulihan?",
                        QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes
                    )
                    if answer == QMessageBox.Yes:
                        open_path = recovery_path
                tab = DocumentTab(open_path)
                self.tabs.addTab(tab, os.path.basename(path))
                add_recent(path)
                self.tabs.setCurrentWidget(tab)
                self.statusBar().showMessage("%d pages loaded" % tab.backend.page_count, 4000)
            except Exception as e:
                QMessageBox.critical(self, "Cannot open PDF", str(e))

    def close_tab(self, index):
        tab = self.tabs.widget(index)
        if tab: tab.close_document()
        self.tabs.removeTab(index)


    def search_pdf(self):
        tab = self.current_tab()
        if not tab:
            QMessageBox.information(self, "NeoPDF", "Buka PDF terlebih dahulu.")
            return
        query, ok = QInputDialog.getText(self, "Cari di PDF", "Masukkan kata atau frasa:")
        if not ok or not query.strip():
            return
        hits = []
        for page_index in range(tab.backend.page_count):
            try:
                matches = tab.backend.doc[page_index].search_for(query.strip())
            except Exception:
                matches = []
            if matches:
                hits.append((page_index, len(matches)))
        if not hits:
            QMessageBox.information(self, "Hasil pencarian", "Tidak ditemukan: " + query)
            return
        options = ["Halaman %d — %d hasil" % (idx + 1, count) for idx, count in hits]
        chosen, accepted = QInputDialog.getItem(self, "Hasil pencarian", "Pilih halaman:", options, 0, False)
        if accepted:
            target = hits[options.index(chosen)][0]
            tab.page = target
            tab.viewer.show_page(target)
            self.statusBar().showMessage("Ditemukan %d halaman yang cocok." % len(hits), 5000)

    def save_as(self):
        tab = self.current_tab()
        if not tab:
            QMessageBox.information(self, "NeoPDF", "Buka PDF terlebih dahulu.")
            return
        suggested = os.path.splitext(os.path.basename(tab.backend.path or "document.pdf"))[0] + "_edited.pdf"
        out, _ = QFileDialog.getSaveFileName(self, "Simpan salinan PDF", suggested, "PDF files (*.pdf)")
        if not out:
            return
        try:
            tab.backend.save(out)
            self.tabs.setTabText(self.tabs.currentIndex(), os.path.basename(out))
            self.statusBar().showMessage("Dokumen disimpan: " + out, 5000)
        except Exception as exc:
            QMessageBox.critical(self, "Gagal menyimpan", str(exc))

    def open_print(self):
        tab = self.current_tab()
        if not tab:
            QMessageBox.information(self, "NeoPDF", "Open a PDF first."); return
        PrintDialog(tab.backend, self).exec_()

    def zoom(self, factor):
        tab = self.current_tab()
        if tab: tab.viewer.set_zoom(tab.viewer.zoom * factor)

    def navigate(self, delta):
        tab = self.current_tab()
        if not tab: return
        tab.page = max(0, min(tab.backend.page_count - 1, tab.page + delta))
        tab.viewer.show_page(tab.page)
        self.statusBar().showMessage("Page %d of %d" % (tab.page + 1, tab.backend.page_count))

    def page_management(self):
        tab = self.current_tab()
        if not tab:
            QMessageBox.information(self, "NeoPDF", "Open a PDF first."); return
        menu = ["Rotate pages", "Extract pages", "Delete pages", "Reorder pages", "Split document", "Merge PDFs"]
        choice, ok = QInputDialog.getItem(self, "Page Management", "Choose operation:", menu, 0, False)
        if not ok: return
        try:
            if choice == "Merge PDFs": merge_dialog(self, tab.backend)
            elif choice == "Reorder pages":
                if ReorderDialog(tab.backend, self).exec_():
                    tab.viewer.refresh()
            elif choice == "Split document": split_dialog(self, tab.backend)
            elif choice in ("Rotate pages", "Extract pages", "Delete pages"):
                text, ok = QInputDialog.getText(self, "Page numbers", "Enter 1-based page numbers, e.g. 1,3,5:")
                if not ok: return
                pages = [int(x.strip()) - 1 for x in text.split(",") if x.strip()]
                if any(p < 0 or p >= tab.backend.page_count for p in pages):
                    raise ValueError("Page number outside document range")
                if choice == "Rotate pages":
                    deg, ok = QInputDialog.getInt(self, "Rotate", "Degrees:", 90, 90, 270, 90)
                    if ok: tab.backend.rotate_pages(pages, deg)
                elif choice == "Extract pages":
                    out, _ = QFileDialog.getSaveFileName(self, "Save extracted pages", "extracted.pdf", "PDF files (*.pdf)")
                    if out: tab.backend.extract_pages(pages, out)
                else:
                    tab.backend.delete_pages(pages)
                if choice != "Extract pages":
                    out, _ = QFileDialog.getSaveFileName(self, "Save modified PDF", "edited.pdf", "PDF files (*.pdf)")
                    if out: tab.backend.save(out)
                    tab.viewer.show_page(min(tab.page, tab.backend.page_count - 1))
            QMessageBox.information(self, "NeoPDF", "Operation completed.")
        except Exception as e: QMessageBox.critical(self, "Operation failed", str(e))

    def protect_pdf(self):
        tab = self.current_tab()
        if not tab:
            QMessageBox.information(self, "NeoPDF", "Open a PDF first."); return
        protect_dialog(self, tab.backend)

    def annotate(self, kind):
        tab = self.current_tab()
        if not tab:
            QMessageBox.information(self, "NeoPDF", "Open a PDF first."); return
        phrase, ok = QInputDialog.getText(self, "Anotasi teks", "Masukkan teks persis yang ingin ditandai:")
        if not ok or not phrase.strip():
            return
        try:
            page = tab.backend.doc[tab.page]
            matches = page.search_for(phrase.strip())
            if not matches:
                QMessageBox.information(self, "Anotasi", "Teks tidak ditemukan pada halaman aktif.")
                return
            for rect in matches:
                tab.backend.annotate(tab.page, rect, kind)
            out, _ = QFileDialog.getSaveFileName(self, "Simpan PDF beranotasi", "annotated.pdf", "PDF files (*.pdf)")
            if out:
                tab.backend.save(out)
                tab.viewer.refresh()
                QMessageBox.information(self, "NeoPDF", "Anotasi disimpan.")
        except Exception as exc:
            QMessageBox.critical(self, "Anotasi gagal", str(exc))


    def _autosave_documents(self):
        for index in range(self.tabs.count()):
            tab = self.tabs.widget(index)
            try:
                create_recovery_snapshot(tab.backend)
            except Exception as exc:
                self.statusBar().showMessage("Autosave gagal: " + str(exc), 5000)

    def reorder_pages(self):
        tab = self.current_tab()
        if not tab:
            QMessageBox.information(self, "NeoPDF", "Buka PDF terlebih dahulu.")
            return
        if ReorderDialog(tab.backend, self).exec_():
            tab.viewer.refresh()
            self.statusBar().showMessage("Urutan halaman diperbarui. Simpan sebagai PDF untuk mempertahankan perubahan.", 5000)

    def replace_text(self):
        tab = self.current_tab()
        if not tab:
            QMessageBox.information(self, "NeoPDF", "Buka PDF terlebih dahulu.")
            return
        old, ok = QInputDialog.getText(self, "Ganti teks", "Teks yang dicari pada halaman aktif:")
        if not ok or not old:
            return
        new, ok = QInputDialog.getText(self, "Ganti teks", "Teks pengganti:")
        if not ok:
            return
        try:
            count = tab.backend.replace_text_region(tab.page, old, new)
            if not count:
                QMessageBox.information(self, "NeoPDF", "Teks tidak ditemukan.")
                return
            out, _ = QFileDialog.getSaveFileName(self, "Simpan hasil", "edited_text.pdf", "PDF files (*.pdf)")
            if out:
                tab.backend.save(out)
                tab.viewer.refresh()
                QMessageBox.information(self, "NeoPDF", "%d bagian teks diganti." % count)
        except Exception as exc:
            QMessageBox.critical(self, "Gagal mengganti teks", str(exc))


    def edit_objects(self):
        tab=self.current_tab()
        if not tab:
            QMessageBox.information(self,"NeoPDF","Buka PDF terlebih dahulu.")
            return
        dialog=ObjectEditorDialog(tab.backend,tab.page,self)
        if dialog.exec_():
            tab.viewer.refresh()
            self.statusBar().showMessage("Editor objek halaman ditutup.",3000)

    def insert_image(self):
        tab = self.current_tab()
        if not tab:
            QMessageBox.information(self, "NeoPDF", "Buka PDF terlebih dahulu.")
            return
        image_path, _ = QFileDialog.getOpenFileName(self, "Pilih gambar", "", "Images (*.png *.jpg *.jpeg *.bmp)")
        if not image_path:
            return
        try:
            page = tab.backend.doc[tab.page]
            rect = page.rect
            # Insert centered image at about one-third of the page dimensions.
            w, h = rect.width * 0.35, rect.height * 0.25
            target = fitz.Rect(rect.width * 0.325, rect.height * 0.375,
                               rect.width * 0.325 + w, rect.height * 0.375 + h)
            tab.backend.insert_image(tab.page, image_path, target)
            out, _ = QFileDialog.getSaveFileName(self, "Simpan PDF dengan gambar", "image_added.pdf", "PDF files (*.pdf)")
            if out:
                tab.backend.save(out)
                tab.viewer.refresh()
        except Exception as exc:
            QMessageBox.critical(self, "Gagal menyisipkan gambar", str(exc))

    def show_settings(self):
        SettingsDialog(self).exec_()
