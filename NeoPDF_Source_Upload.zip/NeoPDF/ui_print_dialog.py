"""Dual-pane print dialog with live pricing and real Qt printer submission."""
import re
from PyQt5.QtCore import Qt, QSizeF
from PyQt5.QtGui import QPixmap, QImage, QPainter
from PyQt5.QtPrintSupport import QPrinter, QPrinterInfo, QPrintDialog
from pricing_config import load_pricing
from PyQt5.QtWidgets import (
    QDialog, QHBoxLayout, QVBoxLayout, QFormLayout, QGroupBox, QLabel,
    QComboBox, QSpinBox, QLineEdit, QPushButton, QScrollArea, QWidget,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox
)

# Prices are starter defaults in IDR; they can be edited in this module.
DEFAULT_PAPER = {"A4": 0, "F4": 500, "A3": 1500}
DEFAULT_INK = {
    "Hitam Putih": 500, "Hitam Putih Block": 1000,
    "Hitam Putih Block Full": 1500, "Warna Sedikit": 1000,
    "Warna Sedang": 2000, "Warna 50%": 3000, "Warna Full": 4000
}

class PrintDialog(QDialog):
    def __init__(self, backend, parent=None):
        super().__init__(parent)
        self.backend = backend
        self.pricing = load_pricing()
        self.paper_prices = self.pricing["paper"]
        self.ink_prices = self.pricing["ink"]
        self.setWindowTitle("NeoPDF • Print & Smart Pricing")
        self.resize(1180, 790)
        self.rows = []
        self.current_preview = 0
        self._build()
        self._populate_pages()

    def _build(self):
        root = QVBoxLayout(self)
        body = QHBoxLayout()
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left = QWidget()
        lv = QVBoxLayout(left)

        printer_box = QGroupBox("PENGATURAN CETAK")
        form = QFormLayout(printer_box)
        self.printer = QComboBox()
        for p in QPrinterInfo.availablePrinters():
            self.printer.addItem(p.printerName())
        if not self.printer.count():
            self.printer.addItem("Default system printer")
        self.copies = QSpinBox()
        self.copies.setRange(1, 999)
        self.copies.setValue(1)
        self.range_edit = QLineEdit("all")
        self.range_edit.setPlaceholderText("all atau 1-3,5")
        self.paper_global = QComboBox()
        self.paper_global.addItems(self.paper_prices.keys())
        form.addRow("Printer", self.printer)
        form.addRow("Jumlah salinan", self.copies)
        form.addRow("Halaman (all / 1-3,5)", self.range_edit)
        form.addRow("Ukuran kertas default", self.paper_global)
        lv.addWidget(printer_box)

        lv.addWidget(QLabel("KALKULATOR HARGA PER HALAMAN"))
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Halaman", "Coverage %", "Kertas", "Kategori tinta", "Subtotal"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setMinimumWidth(620)
        self.table.setAlternatingRowColors(True)
        lv.addWidget(self.table)
        left_scroll.setWidget(left)
        body.addWidget(left_scroll, 6)

        right = QVBoxLayout()
        right.addWidget(QLabel("PRATINJAU HALAMAN"))
        self.preview = QLabel("Preview")
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(360, 510)
        self.preview.setStyleSheet("background:#26343b;border:1px solid #40535c;border-radius:10px;")
        right.addWidget(self.preview, 1)
        nav = QHBoxLayout()
        self.prev_btn = QPushButton("‹ Sebelumnya")
        self.next_btn = QPushButton("Berikutnya ›")
        self.page_label = QLabel("")
        self.prev_btn.clicked.connect(lambda: self._preview_move(-1))
        self.next_btn.clicked.connect(lambda: self._preview_move(1))
        nav.addWidget(self.prev_btn)
        nav.addWidget(self.page_label, 1, Qt.AlignCenter)
        nav.addWidget(self.next_btn)
        right.addLayout(nav)
        body.addLayout(right, 4)
        root.addLayout(body, 1)

        footer = QHBoxLayout()
        self.total_label = QLabel("TOTAL: Rp0")
        self.total_label.setStyleSheet("font-size:22px;font-weight:700;padding:8px;")
        cancel = QPushButton("Batal")
        cancel.clicked.connect(self.reject)
        self.print_btn = QPushButton("Cetak sekarang")
        self.print_btn.setDefault(True)
        self.print_btn.clicked.connect(self._print)
        footer.addWidget(self.total_label)
        footer.addStretch()
        footer.addWidget(cancel)
        footer.addWidget(self.print_btn)
        root.addLayout(footer)

        self.copies.valueChanged.connect(self._recalculate)
        self.range_edit.textChanged.connect(self._recalculate)
        self.paper_global.currentTextChanged.connect(self._apply_global_paper)

    def _populate_pages(self):
        self.table.setRowCount(self.backend.page_count)
        for i in range(self.backend.page_count):
            classification = self.backend.classify_print_page(i)
            metrics = classification["metrics"]
            coverage = metrics["color_ink_usage"] if metrics["is_color"] else metrics["total_ink_coverage"]
            self.table.setItem(i, 0, QTableWidgetItem(str(i + 1)))
            self.table.setItem(i, 1, QTableWidgetItem("%.2f" % coverage))
            paper = QComboBox()
            paper.addItems(self.paper_prices.keys())
            category = QComboBox()
            category.addItems(self.ink_prices.keys())
            suggested = classification["category"]
            if suggested in self.ink_prices:
                category.setCurrentText(suggested)
            elif not metrics["is_color"]:
                category.setCurrentText("Hitam Putih")
            paper.currentIndexChanged.connect(self._recalculate)
            category.currentIndexChanged.connect(self._recalculate)
            self.table.setCellWidget(i, 2, paper)
            self.table.setCellWidget(i, 3, category)
            self.table.setItem(i, 4, QTableWidgetItem(""))
            self.rows.append((paper, category))
        self._recalculate()
        self._show_preview(0)

    def _parse_pages(self):
        raw = self.range_edit.text().strip().lower()
        if raw in ("", "all"):
            return list(range(self.backend.page_count))
        result = set()
        for part in raw.split(","):
            part = part.strip()
            if re.fullmatch(r"\d+", part):
                start = end = int(part)
            else:
                match = re.fullmatch(r"(\d+)\s*-\s*(\d+)", part)
                if not match:
                    raise ValueError("Format halaman salah. Gunakan all atau 1-3,5.")
                start, end = map(int, match.groups())
            if start < 1 or end < start or end > self.backend.page_count:
                raise ValueError("Nomor halaman di luar jumlah halaman dokumen.")
            result.update(range(start - 1, end))
        return sorted(result)

    def _recalculate(self, *_):
        try:
            selected = set(self._parse_pages())
        except ValueError:
            self.total_label.setText("TOTAL: periksa rentang halaman")
            return
        total = 0
        for i, (paper, category) in enumerate(self.rows):
            amount = self.paper_prices[paper.currentText()] + self.ink_prices[category.currentText()]
            self.table.item(i, 4).setText("Rp{:,.0f}".format(amount).replace(",", "."))
            if i in selected:
                total += amount
        total *= self.copies.value()
        self.total_label.setText("TOTAL: Rp{:,.0f}".format(total).replace(",", "."))

    def _apply_global_paper(self, name):
        for paper, _ in self.rows:
            paper.blockSignals(True)
            paper.setCurrentText(name)
            paper.blockSignals(False)
        self._recalculate()

    def _show_preview(self, index):
        if not self.backend.doc or self.backend.page_count == 0:
            return
        self.current_preview = max(0, min(index, self.backend.page_count - 1))
        pix = self.backend.render_page(self.current_preview, 1.0)
        image = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()
        self.preview.setPixmap(QPixmap.fromImage(image).scaled(
            self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.page_label.setText("Halaman %d / %d" % (self.current_preview + 1, self.backend.page_count))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self.backend.page_count:
            self._show_preview(self.current_preview)

    def _preview_move(self, delta):
        self._show_preview(self.current_preview + delta)

    def _print(self):
        try:
            pages = self._parse_pages()
        except ValueError as exc:
            QMessageBox.warning(self, "Rentang halaman", str(exc))
            return
        if not pages:
            QMessageBox.warning(self, "Cetak", "Tidak ada halaman yang dipilih.")
            return

        printer = QPrinter(QPrinter.HighResolution)
        printer_name = self.printer.currentText()
        if printer_name and printer_name != "Default system printer":
            printer.setPrinterName(printer_name)
        printer.setCopyCount(self.copies.value())
        paper_name = self.paper_global.currentText()
        if paper_name == "A4":
            printer.setPaperSize(QPrinter.A4)
        elif paper_name == "A3":
            printer.setPaperSize(QPrinter.A3)
        else:
            printer.setPaperSize(QSizeF(215.9, 330.2), QPrinter.Millimeter)  # F4/Folio approx.

        dialog = QPrintDialog(printer, self)
        dialog.setWindowTitle("Pengaturan printer — NeoPDF")
        if dialog.exec_() != QPrintDialog.Accepted:
            return

        painter = QPainter()
        if not painter.begin(printer):
            QMessageBox.critical(self, "Cetak gagal", "Tidak dapat memulai pekerjaan cetak. Periksa printer dan driver.")
            return
        try:
            for position, page_index in enumerate(pages):
                if position:
                    printer.newPage()
                page_pix = self.backend.render_page(page_index, 2.0)
                image = QImage(page_pix.samples, page_pix.width, page_pix.height,
                               page_pix.stride, QImage.Format_RGB888)
                rect = printer.pageRect()
                scaled = image.scaled(int(rect.width()), int(rect.height()),
                                      Qt.KeepAspectRatio, Qt.SmoothTransformation)
                x = int(rect.x() + (rect.width() - scaled.width()) / 2)
                y = int(rect.y() + (rect.height() - scaled.height()) / 2)
                painter.drawImage(x, y, scaled)
        except Exception as exc:
            painter.end()
            QMessageBox.critical(self, "Cetak gagal", str(exc))
            return
        painter.end()
        QMessageBox.information(self, "NeoPDF", "Pekerjaan cetak telah dikirim ke printer.")
        self.accept()
