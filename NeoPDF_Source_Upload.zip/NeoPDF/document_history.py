"""Recent-document history and crash-recovery snapshots."""
import json
import os
import shutil
from datetime import datetime

def data_dir():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    path = os.path.join(base, "NeoPDF")
    os.makedirs(path, exist_ok=True)
    return path

def history_file():
    return os.path.join(data_dir(), "recent.json")

def add_recent(path, limit=20):
    path = os.path.abspath(path)
    try:
        items = load_recent()
    except Exception:
        items = []
    items = [x for x in items if x.get("path") != path]
    items.insert(0, {"path": path, "opened": datetime.now().isoformat(timespec="seconds")})
    with open(history_file(), "w", encoding="utf-8") as f:
        json.dump(items[:limit], f, indent=2, ensure_ascii=False)

def load_recent():
    try:
        with open(history_file(), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []

def autosave_path(source_path):
    safe = os.path.basename(source_path or "untitled.pdf").replace(" ", "_")
    return os.path.join(data_dir(), "recovery_" + safe)

def create_recovery_snapshot(backend):
    target = autosave_path(backend.path)
    backend.autosave_copy(target)
    return target

def remove_recovery_snapshot(source_path):
    target = autosave_path(source_path)
    if os.path.exists(target):
        os.remove(target)
