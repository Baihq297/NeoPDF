"""NeoPDF - lightweight PDF reader, editor and smart print calculator."""
import sys
from PyQt5.QtWidgets import QApplication
from qt_material import apply_stylesheet
from ui_main import MainWindow

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("NeoPDF")
    try:
        apply_stylesheet(app, theme="dark_teal.xml")
    except Exception:
        pass
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
