"""Build standalone NeoPDF x64 executable.

Usage:
  py -3.8 build_exe.py legacy
  py -3.11 build_exe.py modern

Build the legacy profile on a Windows 7 SP1 x64 test/build machine whenever
possible. A successful build on a newer Windows version does not prove that
the result runs on Windows 7.
"""
import argparse
import struct
import sys
from pathlib import Path

import PyInstaller.__main__

PROFILES = {
    "legacy": {
        "name": "NeoPDF-Legacy-x64",
        "python": (3, 8),
        "description": "Windows 7 SP1 x64 compatibility build",
    },
    "modern": {
        "name": "NeoPDF-x64",
        "python": (3, 11),
        "description": "Windows 8.1/10/11 x64 build",
    },
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", choices=PROFILES)
    args = parser.parse_args()
    profile = PROFILES[args.profile]

    if struct.calcsize("P") != 8:
        raise SystemExit("NeoPDF hanya dibangun untuk Python Windows 64-bit.")
    if sys.version_info[:2] != profile["python"]:
        wanted = ".".join(map(str, profile["python"]))
        raise SystemExit(
            f"Profil {args.profile} memerlukan Python {wanted} x64; "
            f"yang aktif {sys.version.split()[0]}."
        )
    if sys.platform != "win32":
        raise SystemExit("Build EXE Windows harus dijalankan di Windows.")

    root = Path(__file__).resolve().parent
    args = [
        str(root / "main.py"),
        f"--name={profile['name']}",
        "--onefile",
        "--windowed",
        "--clean",
        "--noconfirm",
        "--hidden-import=fitz",
        "--hidden-import=PyQt5.sip",
        "--collect-all=qt_material",
        "--collect-all=fitz",
        f"--version-file={root / 'version_info.txt'}",
        f"--distpath={root / 'dist' / args.profile}",
        f"--workpath={root / 'build' / args.profile}",
        f"--specpath={root / 'build' / args.profile}",
    ]
    PyInstaller.__main__.run(args)

if __name__ == "__main__":
    main()
