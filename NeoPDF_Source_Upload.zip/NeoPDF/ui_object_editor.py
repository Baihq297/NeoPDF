"""Page object inspector for text and image objects."""
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
    QLabel, QPushButton, QInputDialog, QFileDialog, QMessageBox
)

class ObjectEditorDialog(QDialog):
    def __init__(self, backend, page_index, parent=None):
        super().__init__(parent)
        self.backend = backend
        self.page_index = page_index
        self.objects = backend.inspect_page_objects(page_index)
        self.setWindowTitle("NeoPDF • Page Object Editor")
        self.resize(720, 560)
        layout=QVBoxLayout(self)
        layout.addWidget(QLabel("Pilih objek teks atau gambar pada halaman aktif."))
        self.list=QListWidget()
        for obj in self.objects:
            if obj["kind"]=="text":
                label="TEXT  •  "+obj["text"].replace("\n"," ")[:100]
            else:
                label="IMAGE  •  "+str(obj["rect"])
            item=QListWidgetItem(label)
            item.setData(Qt.UserRole,obj)
            self.list.addItem(item)
        layout.addWidget(self.list)
        buttons=QHBoxLayout()
        self.edit_text=QPushButton("Ganti teks terpilih")
        self.replace_image=QPushButton("Ganti gambar terpilih")
        close=QPushButton("Tutup")
        self.edit_text.clicked.connect(self._edit_text)
        self.replace_image.clicked.connect(self._replace_image)
        close.clicked.connect(self.accept)
        buttons.addWidget(self.edit_text)
        buttons.addWidget(self.replace_image)
        buttons.addStretch()
        buttons.addWidget(close)
        layout.addLayout(buttons)
        self.list.currentItemChanged.connect(self._selection_changed)
        self._selection_changed(self.list.currentItem(),None)

    def _selected(self):
        item=self.list.currentItem()
        return item.data(Qt.UserRole) if item else None

    def _selection_changed(self, current, previous):
        obj=self._selected()
        self.edit_text.setEnabled(bool(obj and obj["kind"]=="text"))
        self.replace_image.setEnabled(bool(obj and obj["kind"]=="image"))

    def _edit_text(self):
        obj=self._selected()
        if not obj: return
        old=obj["text"]
        new,ok=QInputDialog.getMultiLineText(self,"Ganti teks","Teks pengganti:",old)
        if not ok: return
        try:
            self.backend.replace_text_block(self.page_index,obj["rect"],new)
            QMessageBox.information(self,"NeoPDF","Teks pada area terpilih sudah diganti.")
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self,"Tidak dapat mengganti teks",str(exc))

    def _replace_image(self):
        obj=self._selected()
        if not obj: return
        path,_=QFileDialog.getOpenFileName(self,"Pilih gambar pengganti","","Images (*.png *.jpg *.jpeg *.bmp)")
        if not path: return
        try:
            self.backend.replace_image_xref(self.page_index,obj.get("xref"),path)
            QMessageBox.information(self,"NeoPDF","Resource gambar berhasil diganti.")
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self,"Gagal mengganti gambar",str(exc))
