import os
import tempfile
import unittest
import fitz

from pdf_backend import PDFBackend

class PDFBackendTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.temp.name, "sample.pdf")
        doc = fitz.open()
        page = doc.new_page()
        page.insert_text((72, 72), "NeoPDF test document")
        doc.save(self.path)
        doc.close()
        self.backend = PDFBackend(self.path)

    def tearDown(self):
        self.backend.close()
        self.temp.cleanup()

    def test_page_count(self):
        self.assertEqual(self.backend.page_count, 1)

    def test_searchable_text(self):
        self.assertTrue(self.backend.doc[0].search_for("NeoPDF"))

    def test_page_object_inspection(self):
        objects = self.backend.inspect_page_objects(0)
        self.assertTrue(any(obj["kind"] == "text" for obj in objects))

    def test_classification_returns_metrics(self):
        result = self.backend.classify_print_page(0)
        self.assertIn("category", result)
        self.assertIn("metrics", result)

if __name__ == "__main__":
    unittest.main()
