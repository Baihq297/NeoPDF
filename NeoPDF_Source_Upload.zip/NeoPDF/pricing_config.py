"""Editable print price configuration persisted as JSON beside the user profile."""
import json
import os

DEFAULT_CONFIG = {
    "paper": {"A4": 0, "F4": 500, "A3": 1500},
    "ink": {
        "Hitam Putih": 500,
        "Hitam Putih Block": 1000,
        "Hitam Putih Block Full": 1500,
        "Warna Sedikit": 1000,
        "Warna Sedang": 2000,
        "Warna 50%": 3000,
        "Warna Full": 4000
    }
}

def config_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    folder = os.path.join(base, "NeoPDF")
    if not os.path.isdir(folder):
        os.makedirs(folder)
    return os.path.join(folder, "pricing.json")

def load_pricing():
    path = config_path()
    if not os.path.exists(path):
        save_pricing(DEFAULT_CONFIG)
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data.get("paper"), dict) or not isinstance(data.get("ink"), dict):
            raise ValueError("Invalid pricing config structure")
        return data
    except Exception:
        save_pricing(DEFAULT_CONFIG)
        return json.loads(json.dumps(DEFAULT_CONFIG))

def save_pricing(data):
    path = config_path()
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)
    return path
