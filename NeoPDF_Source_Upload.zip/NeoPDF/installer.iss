; NeoPDF x64 installer. Compile separately for each build profile.
#define MyAppName "NeoPDF"
#define MyAppVersion "6.0.0"
#define MyAppPublisher "NeoPDF Open Source"
#ifndef BuildProfile
  #define BuildProfile "modern"
#endif
#if BuildProfile == "legacy"
  #define MyAppExeName "NeoPDF-Legacy-x64.exe"
  #define OutputName "Setup_NeoPDF_Legacy_Win7_x64"
  #define SourceExe "dist\legacy\NeoPDF-Legacy-x64.exe"
#else
  #define MyAppExeName "NeoPDF-x64.exe"
  #define OutputName "Setup_NeoPDF_Win8-11_x64"
  #define SourceExe "dist\modern\NeoPDF-x64.exe"
#endif

[Setup]
AppId={{7D39F0B7-12A7-4F6B-A9C1-4E0FDF400001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\NeoPDF
DefaultGroupName=NeoPDF
OutputDir=installer_output
OutputBaseFilename={#OutputName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExeName}
PrivilegesRequired=admin
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64

[Files]
Source: "{#SourceExe}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\NeoPDF"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\NeoPDF"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Buat shortcut Desktop"; GroupDescription: "Shortcut:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Jalankan NeoPDF"; Flags: postinstall nowait skipifsilent
