"""PDF viewer with page thumbnails and zoomable page preview."""
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QPixmap, QImage, QIcon
from PyQt5.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout, QScrollArea, QListWidget,
    QListWidgetItem, QSplitter, QSizePolicy
)

class PDFViewer(QWidget):
    def __init__(self, backend, parent=None):
        super().__init__(parent)
        self.backend = backend
        self.zoom = 1.15
        self.page_index = 0
        self.page_changed_callback = None

        self.thumbnails = QListWidget()
        self.thumbnails.setIconSize(QSize(104, 138))
        self.thumbnails.setFixedWidth(150)
        self.thumbnails.currentRowChanged.connect(self._thumbnail_selected)

        self.label = QLabel("Buka dokumen PDF untuk mulai")
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.label.setStyleSheet("background:#39434a;padding:18px;")
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setAlignment(Qt.AlignCenter)
        self.scroll.setWidget(self.label)

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self.thumbnails)
        splitter.addWidget(self.scroll)
        splitter.setStretchFactor(1, 1)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(splitter)

        self._build_thumbnails()
        if self.backend.page_count:
            self.show_page(0)

    def _pixmap_for(self, index, scale):
        pix = self.backend.render_page(index, scale)
        fmt = QImage.Format_RGB888 if pix.n >= 3 else QImage.Format_Grayscale8
        image = QImage(pix.samples, pix.width, pix.height, pix.stride, fmt).copy()
        return QPixmap.fromImage(image)

    def _build_thumbnails(self):
        self.thumbnails.clear()
        for i in range(self.backend.page_count):
            item = QListWidgetItem("Halaman %d" % (i + 1))
            item.setIcon(QIcon(self._pixmap_for(i, 0.20)))
            item.setSizeHint(QSize(130, 165))
            self.thumbnails.addItem(item)
        if self.backend.page_count:
            self.thumbnails.setCurrentRow(0)

    def _thumbnail_selected(self, index):
        if index >= 0 and index != self.page_index:
            self.show_page(index)

    def show_page(self, index):
        if not self.backend.doc or index < 0 or index >= self.backend.page_count:
            return
        self.page_index = index
        pixmap = self._pixmap_for(index, self.zoom)
        self.label.setPixmap(pixmap)
        self.label.resize(pixmap.size())
        if self.thumbnails.currentRow() != index:
            self.thumbnails.blockSignals(True)
            self.thumbnails.setCurrentRow(index)
            self.thumbnails.blockSignals(False)
        if self.page_changed_callback:
            self.page_changed_callback(index)

    def set_zoom(self, value):
        self.zoom = max(0.35, min(4.0, value))
        self.show_page(self.page_index)

    def refresh(self):
        self._build_thumbnails()
        self.show_page(min(self.page_index, self.backend.page_count - 1))
