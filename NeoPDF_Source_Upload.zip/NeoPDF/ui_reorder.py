"""Drag-and-drop page ordering dialog."""
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QListWidget, QListWidgetItem, QHBoxLayout, QPushButton, QMessageBox

class ReorderDialog(QDialog):
    def __init__(self, backend, parent=None):
        super().__init__(parent)
        self.backend = backend
        self.setWindowTitle("Atur Ulang Halaman — NeoPDF")
        self.resize(360, 560)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Seret halaman untuk mengubah urutan."))
        self.list = QListWidget()
        self.list.setDragDropMode(QListWidget.InternalMove)
        self.list.setDefaultDropAction(Qt.MoveAction)
        for i in range(backend.page_count):
            item = QListWidgetItem("Halaman %d" % (i + 1))
            item.setData(Qt.UserRole, i)
            self.list.addItem(item)
        layout.addWidget(self.list)
        buttons = QHBoxLayout()
        cancel = QPushButton("Batal")
        apply_btn = QPushButton("Terapkan urutan")
        cancel.clicked.connect(self.reject)
        apply_btn.clicked.connect(self._apply)
        buttons.addWidget(cancel)
        buttons.addWidget(apply_btn)
        layout.addLayout(buttons)

    def _apply(self):
        order = [self.list.item(i).data(Qt.UserRole) for i in range(self.list.count())]
        try:
            self.backend.reorder_pages(order)
            self.accept()
        except Exception as exc:
            QMessageBox.critical(self, "Gagal mengurutkan", str(exc))
