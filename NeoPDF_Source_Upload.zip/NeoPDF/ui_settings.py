"""Settings dialog for editing NeoPDF print tariffs."""
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget,
    QTableWidgetItem, QPushButton, QHeaderView, QMessageBox, QTabWidget, QWidget
)
from pricing_config import load_pricing, save_pricing

class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("NeoPDF Settings • Tarif Cetak")
        self.resize(620, 560)
        self.data = load_pricing()
        tabs = QTabWidget()
        self.paper_table = self._make_table(self.data["paper"])
        self.ink_table = self._make_table(self.data["ink"])
        paper_page = QWidget(); paper_layout = QVBoxLayout(paper_page)
        paper_layout.addWidget(QLabel("Harga tambahan berdasarkan jenis kertas (Rupiah)"))
        paper_layout.addWidget(self.paper_table)
        ink_page = QWidget(); ink_layout = QVBoxLayout(ink_page)
        ink_layout.addWidget(QLabel("Tarif kategori tinta per halaman (Rupiah)"))
        ink_layout.addWidget(self.ink_table)
        tabs.addTab(paper_page, "Kertas")
        tabs.addTab(ink_page, "Kategori tinta")
        root = QVBoxLayout(self); root.addWidget(tabs)
        buttons = QHBoxLayout()
        save = QPushButton("Simpan tarif"); close = QPushButton("Tutup")
        save.clicked.connect(self._save); close.clicked.connect(self.accept)
        buttons.addStretch(); buttons.addWidget(close); buttons.addWidget(save)
        root.addLayout(buttons)

    def _make_table(self, values):
        table = QTableWidget(len(values), 2)
        table.setHorizontalHeaderLabels(["Nama kategori", "Harga (Rp)"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for row, (name, price) in enumerate(values.items()):
            table.setItem(row, 0, QTableWidgetItem(str(name)))
            table.setItem(row, 1, QTableWidgetItem(str(price)))
        return table

    def _read_table(self, table):
        result = {}
        for row in range(table.rowCount()):
            name_item, price_item = table.item(row, 0), table.item(row, 1)
            if not name_item or not price_item:
                continue
            name = name_item.text().strip()
            if not name:
                raise ValueError("Nama kategori tidak boleh kosong.")
            price = int(price_item.text().replace(".", "").replace(",", "").strip())
            if price < 0:
                raise ValueError("Harga tidak boleh negatif.")
            result[name] = price
        return result

    def _save(self):
        try:
            data = {
                "paper": self._read_table(self.paper_table),
                "ink": self._read_table(self.ink_table)
            }
            if not data["paper"] or not data["ink"]:
                raise ValueError("Minimal satu kategori kertas dan tinta harus tersedia.")
            path = save_pricing(data)
            QMessageBox.information(self, "NeoPDF", "Tarif berhasil disimpan:\n" + path)
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self, "Tarif tidak valid", str(exc))
