# NeoPDF

NeoPDF is a modular PDF reader/editor prototype with a page-level smart print pricing calculator.

## Requirements
- Python 3.8.10
- Windows 7–11 (actual compatibility depends on installed Qt/PyMuPDF binaries and printer drivers)
- Install dependencies: `python -m pip install -r requirements.txt`

## Run
`python main.py`

## Build executable
`python build_exe.py`

The generated executable is placed in `dist/NeoPDF.exe`.

## Modules
- `pdf_backend.py`: PDF operations, rendering and CMYK channel analysis.
- `ui_viewer.py`: scrollable PDF viewer.
- `ui_print_dialog.py`: dual-pane print/pricing dialog.
- `ui_editor.py`: merge, split and password protection dialogs.
- `ui_main.py`: application shell and tab management.

## Notes and known limitations
- The print dialog currently calculates pricing and previews pages, but does not yet submit a native print job. Printer submission, page-range application, paper size mapping, and print-driver properties need to be connected and tested on target printers.
- Highlight/underline backend methods are implemented; interactive text-selection/rectangle tools are not yet wired into the viewer.
- CMYK values are estimates from rendered page pixels, not guaranteed physical ink consumption. The formulas normalize channel values and average them; actual printer coverage varies by driver, profile, media and device.
- Password permissions are advisory in PDF readers and cannot prevent screenshots or all forms of copying.
- Windows 7 compatibility is not guaranteed by current PyQt5/PyMuPDF wheels; validate the exact Python, Qt and VC runtime combination on a Windows 7 test machine.
- Before distributing, add automated tests, error recovery, autosave/backup, and signed installer packaging.


## NeoPDF 2.0 update
The print dialog now uses Qt's `QPrinter` and `QPrintDialog` to submit the rendered selected pages to the chosen printer. It supports copies, page ranges, and A4/A3/F4 paper selection. The operating system's native print dialog exposes driver-specific settings such as duplex and quality when supported by the installed driver.

Printing sends rendered page images, rather than vector PDF objects. This is reliable for a first working print path but can be slower and may rasterize text. Verify margins, scaling and color output on each target printer.


## NeoPDF 3.0 UI and pricing improvements
- Added a left page-thumbnail navigator synchronized with the main preview.
- Added editable paper and ink tariffs in Settings, persisted to `%APPDATA%/NeoPDF/pricing.json` on Windows.
- Print calculator reads the saved tariff configuration.
- Added a text-search annotation workflow for highlight and underline on the active page. It marks every matching text occurrence on that page.
- The annotation operation saves to a new PDF selected by the user; it does not overwrite the source unless the user explicitly chooses the same path.


## NeoPDF 4.0 development milestone
- Added drag-and-drop page reordering dialog.
- Added basic text replacement workflow using PDF redaction plus replacement text overlay.
- Added image insertion workflow (centered placement on active page).
- Added recent document history and recovery snapshot helper module.
- Added Inno Setup script `installer.iss` to generate a conventional Windows installer with Start Menu/Desktop shortcuts and uninstall support.
- Added print-page classification helper based on CMYK coverage.

### Important scope notes
- Text replacement is a visual redaction-and-overlay operation, not native editable text-object editing. Layout, font, and line wrapping can differ from the original.
- Image insertion currently places the selected image in a default centered rectangle; drag-to-resize positioning is not yet implemented.
- Recovery snapshot helpers are included, but a background autosave scheduler and recovery prompt still need UI integration.
- Inno Setup must be installed separately. Build `dist/NeoPDF.exe` on Windows, then compile `installer.iss` using Inno Setup Compiler.
- This source package has not been validated by a Windows GUI or physical printer test in this environment.

- Integrated a 60-second recovery snapshot timer and a recovery prompt when reopening a source document with a prior snapshot.


## NeoPDF 5.0 — READ / EDIT / PRINT workspace
The main navigation is now organized into three explicit work areas:
- **READ:** open multiple PDFs, search document text across pages, page navigation, thumbnails and zoom.
- **EDIT:** page management, drag-and-drop reorder, text replacement workflow, image insertion, highlight/underline, and password protection.
- **PRINT:** page-level CMYK-derived category suggestion, editable tariff pricing, live total, preview and Qt printer submission.

Keyboard shortcuts: `Ctrl+F` searches the active document; `Ctrl+Shift+S` saves an edited copy.

The project remains a development build. Native object-level PDF text editing, freeform annotation selection, advanced print layout (booklet / N-up), and broad Windows-version validation are not included yet.


## NeoPDF 6.0 — Production Edition development build
- Updated application shell styling with a cleaner light workspace and dark navigation sidebar.
- Added a page object inspector that lists text blocks and images, with workflows to replace selected text regions and embedded image resources.
- Added backend object inspection and image replacement functions.
- Added `tests/test_pdf_backend.py` smoke tests for document loading, text search, object inspection, and print classification.
- Added a 64-bit Python guard and executable version metadata to the PyInstaller build.
- Updated Inno Setup installer metadata to NeoPDF 6.0 x64 with normal Windows uninstall registration.

### Important limitations
- The object inspector currently replaces text blocks by redacting the region and overlaying a standard font; it does not preserve the original font object or exact text layout.
- Image replacement uses the page image resource index; PDFs with reused image xrefs or unusual image structures need additional placement-aware mapping.
- The test suite must be run on the target Windows machine after installing requirements: `python -m unittest discover -s tests`.
- Build the EXE with 64-bit Python on Windows. Then compile `installer.iss` using Inno Setup. This environment does not run a Windows GUI, Windows installer, or physical printer, so no such test is claimed.

### Current verification
- Python syntax compilation passed for all application and test modules.
- Backend smoke tests passed in the available Python environment: 4 tests (`python -m unittest discover -s tests`).
- This does not replace Windows GUI, 64-bit packaging, installer, or physical printer acceptance testing.


## NeoPDF 6.0 — Standalone Windows x64 packaging profiles

NeoPDF is packaged as a standalone EXE. End users do **not** need to install
Python or the Python libraries. The two build profiles are:

| Installer | Target OS | Build interpreter |
|---|---|---|
| Legacy x64 | Windows 7 SP1 x64 (compatibility target) | Python 3.8 x64 |
| Modern x64 | Windows 8.1 / 10 / 11 x64 | Python 3.11 x64 |

Windows 8 (non-8.1) is not included in the Modern profile's verified target
claim. It must be tested separately before being advertised as supported.

### Build Legacy package
1. Use a Windows 7 SP1 x64 build/test VM or physical machine where possible.
2. Install Python 3.8 x64 and ensure the Python Launcher (`py`) is available.
3. Run `build_legacy_win7_x64.bat`.
4. Output: `dist\legacy\NeoPDF-Legacy-x64.exe`.
5. Compile the installer with Inno Setup using `compile_installer_legacy.bat`.

### Build Modern package
1. Use Windows 10/11 x64 with Python 3.11 x64.
2. Run `build_modern_win8_11_x64.bat`.
3. Output: `dist\modern\NeoPDF-x64.exe`.
4. Compile the installer with Inno Setup using `compile_installer_modern.bat`.

### Compatibility and release gate
These are build profiles, not proof of OS compatibility. The Windows 7 profile
must be run on a clean Windows 7 SP1 x64 machine and tested for startup, opening
large PDFs, search, edit/save, printing, uninstall, and missing-runtime behavior.
Do the same smoke test on Windows 8.1, 10 and 11 for the Modern package.
Keep the profiles separate: do not copy the Modern EXE into the Legacy installer.

The EXE bundles Python and its application dependencies. Windows printer drivers
remain supplied by Windows/printer manufacturers. Some Windows 7 machines may
also require supported Microsoft runtime updates. Do not distribute either
installer as fully verified until those machine tests pass.

The app is currently a development build. CMYK coverage is an estimate, and
text replacement is a redaction-and-overlay operation rather than native
editable PDF text. The build scripts do not create a signed installer.


## Build EXE otomatis (tanpa file BAT)

NeoPDF menyediakan workflow GitHub Actions di
`.github/workflows/build-windows-exe.yml`. Workflow membangun dua artefak
`.exe` x64 secara terpisah:
- `NeoPDF-Legacy-x64.exe` (profil Python 3.8)
- `NeoPDF-x64.exe` (profil Python 3.11)

Untuk menjalankannya, unggah/push seluruh source NeoPDF ke repository GitHub,
buka tab **Actions**, pilih **Build NeoPDF Windows EXE**, lalu tekan
**Run workflow**. Setelah workflow selesai, unduh EXE dari bagian **Artifacts**.

Workflow ini menghasilkan EXE standalone, bukan installer Setup. Installer
Setup_NeoPDF.exe dapat dibuat terpisah dengan Inno Setup setelah EXE tersedia.
Belum ada EXE Windows yang dikompilasi dari lingkungan ini. Windows 7 SP1 x64
tetap wajib diuji pada perangkat/VM Windows 7 asli sebelum kompatibilitasnya
dinyatakan terverifikasi.
