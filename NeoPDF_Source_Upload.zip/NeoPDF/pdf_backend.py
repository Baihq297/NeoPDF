"""PDF operations and CMYK ink-coverage analysis using PyMuPDF."""
import os
import re
import fitz
import numpy as np

class PDFBackend:
    def __init__(self, path=None):
        self.path = path
        self.doc = fitz.open(path) if path else None

    def open(self, path):
        self.close()
        self.path = path
        self.doc = fitz.open(path)
        return len(self.doc)

    def close(self):
        if self.doc is not None:
            self.doc.close()
            self.doc = None

    @property
    def page_count(self):
        return len(self.doc) if self.doc else 0

    def render_page(self, page_index, scale=1.35, cmyk=False):
        page = self.doc.load_page(page_index)
        matrix = fitz.Matrix(scale, scale)
        cs = fitz.csCMYK if cmyk else fitz.csRGB
        pix = page.get_pixmap(matrix=matrix, colorspace=cs, alpha=False)
        return pix

    def page_png_bytes(self, page_index, scale=1.35):
        return self.render_page(page_index, scale).tobytes("png")

    def analyze_ink(self, page_index, scale=0.35):
        """Return percentages based on average normalized CMYK channel values.

        PyMuPDF CMYK pixmaps expose four samples per pixel. This implementation
        normalizes each channel from 0..255 to 0..1 before averaging.
        """
        pix = self.render_page(page_index, scale=scale, cmyk=True)
        arr = np.frombuffer(pix.samples, dtype=np.uint8)
        arr = arr.reshape(pix.height, pix.width, pix.n)
        if pix.n < 4:
            raise RuntimeError("CMYK rendering did not return four channels")
        cmyk = arr[:, :, :4].astype(np.float32) / 255.0
        c, m, y, k = [cmyk[:, :, i] for i in range(4)]
        color_usage = float(np.mean(c + m + y) / 3.0 * 100.0)
        total_coverage = float(np.mean(c + m + y + k) / 4.0 * 100.0)
        return {
            "color_ink_usage": round(color_usage, 2),
            "total_ink_coverage": round(total_coverage, 2),
            "is_color": color_usage >= 1.5,
        }

    @staticmethod
    def merge(files, output_path):
        out = fitz.open()
        for path in files:
            src = fitz.open(path)
            out.insert_pdf(src)
            src.close()
        out.save(output_path, garbage=4, deflate=True)
        out.close()

    def split(self, ranges, output_dir):
        """Split using 1-based ranges such as ['1-5', '6-10']."""
        os.makedirs(output_dir, exist_ok=True)
        outputs = []
        for n, spec in enumerate(ranges, 1):
            match = re.fullmatch(r"\s*(\d+)\s*-\s*(\d+)\s*", spec)
            if not match:
                raise ValueError("Range must use start-end format, e.g. 1-5")
            start, end = map(int, match.groups())
            if start < 1 or end < start or end > self.page_count:
                raise ValueError("Invalid page range: " + spec)
            out = fitz.open()
            out.insert_pdf(self.doc, from_page=start - 1, to_page=end - 1)
            path = os.path.join(output_dir, "split_%02d.pdf" % n)
            out.save(path, garbage=4, deflate=True)
            out.close()
            outputs.append(path)
        return outputs

    def rotate_pages(self, pages, degrees):
        if degrees not in (90, 180, 270):
            raise ValueError("Rotation must be 90, 180 or 270 degrees")
        for p in pages:
            self.doc[p].set_rotation((self.doc[p].rotation + degrees) % 360)

    def extract_pages(self, pages, output_path):
        out = fitz.open()
        for p in pages:
            out.insert_pdf(self.doc, from_page=p, to_page=p)
        out.save(output_path, garbage=4, deflate=True)
        out.close()

    def delete_pages(self, pages):
        for p in sorted(set(pages), reverse=True):
            if 0 <= p < self.page_count:
                self.doc.delete_page(p)
        if self.page_count == 0:
            raise ValueError("A PDF must contain at least one page.")

    def save(self, output_path=None):
        if not self.doc:
            raise RuntimeError("No document is open")
        path = output_path or self.path
        if not path:
            raise ValueError("Choose a destination file")
        self.doc.save(path, garbage=4, deflate=True, encryption=fitz.PDF_ENCRYPT_KEEP)
        self.path = path
        return path

    def protect(self, output_path, user_password, owner_password):
        if not self.doc:
            raise RuntimeError("No document is open")
        self.doc.save(
            output_path, garbage=4, deflate=True,
            encryption=fitz.PDF_ENCRYPT_AES_256,
            owner_pw=owner_password, user_pw=user_password,
            permissions=fitz.PDF_PERM_PRINT
        )
        return output_path

    def annotate(self, page_index, rect, kind="highlight"):
        page = self.doc[page_index]
        if kind == "highlight":
            annot = page.add_highlight_annot(rect)
        else:
            annot = page.add_underline_annot(rect)
        annot.update()
        return annot
    def reorder_pages(self, new_order):
        """Reorder pages using a complete zero-based permutation."""
        if sorted(new_order) != list(range(self.page_count)):
            raise ValueError("Urutan halaman harus memuat setiap halaman tepat satu kali.")
        out = fitz.open()
        for page_index in new_order:
            out.insert_pdf(self.doc, from_page=page_index, to_page=page_index)
        old = self.doc
        self.doc = out
        old.close()

    def autosave_copy(self, destination):
        """Write a recoverable snapshot without changing the active document path."""
        if not self.doc:
            raise RuntimeError("No document is open")
        self.doc.save(destination, garbage=4, deflate=True, encryption=fitz.PDF_ENCRYPT_KEEP)
        return destination

    def replace_text_region(self, page_index, search_text, replacement_text):
        """Redact matching text and insert replacement text in the same bounding boxes.

        This is a visual replacement, not true editing of the original text objects.
        Font matching and complex multi-line layouts may require manual adjustment.
        """
        page = self.doc[page_index]
        matches = page.search_for(search_text)
        if not matches:
            return 0
        for rect in matches:
            page.add_redact_annot(rect, fill=(1, 1, 1))
        page.apply_redactions(images=0, graphics=0)
        for rect in matches:
            page.insert_textbox(rect, replacement_text, fontsize=max(6, min(12, rect.height * 0.65)),
                                fontname="helv", color=(0, 0, 0), overlay=True)
        return len(matches)

    def insert_image(self, page_index, image_path, rect):
        """Insert an image into a page rectangle."""
        self.doc[page_index].insert_image(rect, filename=image_path, keep_proportion=True)
    def classify_print_page(self, page_index):
        """Classify rendered page ink profile into configurable shop categories."""
        metrics = self.analyze_ink(page_index)
        color = metrics["color_ink_usage"]
        total = metrics["total_ink_coverage"]
        if color < 1.5:
            category = "Hitam Putih Block Full" if total >= 28 else (
                "Hitam Putih Block" if total >= 12 else "Hitam Putih"
            )
        elif color < 12:
            category = "Warna Sedikit"
        elif color < 35:
            category = "Warna Sedang"
        elif color < 65:
            category = "Warna 50%"
        else:
            category = "Warna Full"
        return {"category": category, "metrics": metrics}


    def inspect_page_objects(self, page_index):
        """Return selectable text blocks and image placements on a page."""
        page = self.doc[page_index]
        objects = []
        for block_index, block in enumerate(page.get_text("dict").get("blocks", [])):
            if block.get("type") == 0:
                text = "".join(
                    span.get("text", "")
                    for line in block.get("lines", [])
                    for span in line.get("spans", [])
                ).strip()
                if text:
                    objects.append({
                        "kind": "text",
                        "index": block_index,
                        "text": text,
                        "rect": fitz.Rect(block["bbox"])
                    })
            elif block.get("type") == 1:
                block_rect = fitz.Rect(block["bbox"])
                image_xref = None
                for image_info in page.get_image_info(xrefs=True):
                    if fitz.Rect(image_info["bbox"]).intersects(block_rect):
                        image_xref = image_info.get("xref")
                        break
                objects.append({
                    "kind": "image",
                    "index": block_index,
                    "xref": image_xref,
                    "image": block.get("image"),
                    "rect": block_rect
                })
        return objects

    def replace_image(self, page_index, image_index, image_path):
        """Replace an embedded image resource by its page image-list index."""
        page = self.doc[page_index]
        images = page.get_images(full=True)
        if image_index < 0 or image_index >= len(images):
            raise IndexError("Indeks gambar tidak ditemukan.")
        self.replace_image_xref(page_index, images[image_index][0], image_path)

    def replace_image_xref(self, page_index, xref, image_path):
        """Replace a specific embedded image resource by xref."""
        if not xref:
            raise ValueError("Tidak dapat mengidentifikasi resource gambar pada halaman ini.")
        self.doc[page_index].replace_image(xref, filename=image_path)

    def replace_text_block(self, page_index, rect, replacement_text):
        """Replace text in a selected block using redaction and a new text overlay."""
        page = self.doc[page_index]
        rect = fitz.Rect(rect)
        page.add_redact_annot(rect, fill=(1, 1, 1))
        page.apply_redactions(images=0, graphics=0)
        result = page.insert_textbox(
            rect, replacement_text, fontsize=max(6, min(12, rect.height * 0.65)),
            fontname="helv", color=(0, 0, 0), overlay=True
        )
        if result < 0:
            raise ValueError("Teks pengganti tidak muat dalam area asli. Gunakan teks lebih pendek.")
        return True

    def save(self, output_path=None):
        if not self.doc:
            raise RuntimeError("No document is open")
        path = output_path or self.path
        if not path:
            raise ValueError("Choose a destination file")
        path = os.path.abspath(path)
        current = os.path.abspath(self.path) if self.path else None
        if current and path == current:
            # PyMuPDF cannot normally overwrite the open source file with save().
            self.doc.saveIncr()
        else:
            self.doc.save(path, garbage=4, deflate=True, encryption=fitz.PDF_ENCRYPT_KEEP)
            self.path = path
        return path
